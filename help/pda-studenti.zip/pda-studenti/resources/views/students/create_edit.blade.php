@extends('layouts.app')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-4">
        <form method="post" action="{{ $student->exists ? route('students.update', $student->id) : route('students.store') }}">
            @csrf
            @if($student->exists)
            @method('PATCH')
            @endif
            <div class="mb-3">
                <label for="firstname" class="form-label">Meno</label>
                <input value="{{ old('firstname', $student->firstname) }}" type="text" name="firstname" class="form-control" id="firtstname" placeholder="Zadajte meno">
            </div>
            <div class="mb-3">
                <label for="lastname" class="form-label">Priezvisko</label>
                <input value="{{ old('lastname', $student->lastname) }}" type="text" name="lastname" class="form-control" id="lastname" placeholder="Zadajte priezvisko">
            </div>
            <div class="mb-3">
                <label for="workplace_id" class="form-label">Pracovisko</label>
                <select class="form-select form-select-lg mb-3" id="workplace_id" name="workplace_id">
                    @unless($student->exists)
                    <option selected>Open this select menu</option>
                    @endunless
                    @foreach($workplaces as $workplace)
                    <option value="{{ $workplace->id }}" {{ $workplace->id === old('workplace_id', $student->workplace->id ?? '' ) ? ' selected ' : '' }}>{{  $workplace->name }}</option>
                    @endforeach 
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Uložiť</button>
        </form>
    </div>
</div>
@endsection