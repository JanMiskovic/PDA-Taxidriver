@extends('layouts.app')

@section('content')

<a class="btn btn-lg btn-primary mb-3" href="{{ route('students.create') }}">Vytvoriť</a>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Meno</th>
      <th scope="col">Priezvisko</th>
      <th scope="col">Pracovisko</th>
      <th scope="col">Akcie</th>
    </tr>
  </thead>
  <tbody>
  @foreach($students as $student)
    <tr>
    <th scope="row">{{ $student -> id}}</th>
    <td>{{ $student -> firstname}}</td>
    <td>{{ $student -> lastname}}</td>
    <td>{{ $student -> workplace_id}}</td>
    <td>
    <a class="btn btn-sm btn-outline-primary" href="{{ route('students.edit', $student->id) }}">e</a>
    <form class="d-inline-block" method="post" action="{{ route('students.destroy', $student->id) }}">
      @csrf
      @method('delete')
      <button type="submit" class="btn btn-sm btn-outline-danger">x</button>
    </form>
    </td>
    </tr>
    @endforeach
  </tbody>
</table>


@endsection