

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-4">
        <form method="post" action="<?php echo e($student->exists ? route('students.update', $student->id) : route('students.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if($student->exists): ?>
            <?php echo method_field('PATCH'); ?>
            <?php endif; ?>
            <div class="mb-3">
                <label for="firstname" class="form-label">Meno</label>
                <input type="text" name="firstname" class="form-control" id="firtstname" placeholder="Zadajte meno">
            </div>
            <div class="mb-3">
                <label for="lastname" class="form-label">Priezvisko</label>
                <input type="text" name="lastname" class="form-control" id="lastname" placeholder="Zadajte priezvisko">
            </div>
            <div class="mb-3">
                <label for="workplace_id" class="form-label">Pracovisko</label>
                <select class="form-select form-select-lg mb-3" id="workplace_id" name="workplace_id">
                    <?php if (! ($student->exists)): ?>
                    <option selected>Open this select menu</option>
                    <?php endif; ?>
                    <?php $__currentLoopData = $workplaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workplace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($workplace->id); ?>"><?php echo e($workplace->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Uložiť</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pda-studenti\resources\views/students/create_edit.blade.php ENDPATH**/ ?>