<?php

namespace Database\Seeders;

use App\Models\Student;
use App\Models\Workplace;
use Illuminate\Database\Seeder;

class StudentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $students = Student::factory()
        ->has(Workplace::factory())
        ->count(15)
        ->create();
    }
}
