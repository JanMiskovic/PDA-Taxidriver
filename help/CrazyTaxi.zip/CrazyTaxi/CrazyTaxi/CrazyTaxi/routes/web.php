<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AutoController;
use App\Http\Controllers\CestaController;
use App\Http\Controllers\MestoController;
use App\Http\Controllers\SluzbaController;
use App\Http\Controllers\TaxikarController;
use App\Http\Controllers\UlicaController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::resource('auto', AutoController::class);

Route::resource('cesta', CestaController::class);

Route::resource('mesto', MestoController::class);

Route::resource('sluzba', SluzbaController::class);

Route::resource('taxikar', TaxikarController::class);

Route::resource('ulica', UlicaController::class);

