<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSluzbasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sluzbas', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('taxikar_id')->nullable();
            $table->foreign('taxikar_id')
                ->references('id')
                ->on('taxikars')
                ->onDelete('set null');
            $table->unsignedBigInteger('auto_id')->nullable();
            $table->foreign('auto_id')
                ->references('id')
                ->on('autos')
                ->onDelete('set null');
            $table->time('cas_od');
            $table->time('cas_do');
            $table->date('datum');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sluzbas');
    }
}
