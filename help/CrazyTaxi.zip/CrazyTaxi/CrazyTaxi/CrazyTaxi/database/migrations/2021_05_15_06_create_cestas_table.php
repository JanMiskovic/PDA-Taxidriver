<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCestasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cestas', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('sluzba_id')->nullable();
            $table->foreign('sluzba_id')
                ->references('id')
                ->on('sluzbas')
                ->onDelete('set null');
            $table->unsignedBigInteger('start_ulica_id')->nullable();
            $table->foreign('start_ulica_id')
                ->references('id')
                ->on('ulicas')
                ->onDelete('set null');
            $table->unsignedBigInteger('koniec_ulica_id')->nullable();
            $table->foreign('koniec_ulica_id')
                ->references('id')
                ->on('ulicas')
                ->onDelete('set null');
            $table->float('cena');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cestas');
    }
}
