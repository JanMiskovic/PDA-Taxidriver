<?php

namespace Database\Seeders;

use App\Models\cesta;
use App\Models\sluzba;
use App\Models\ulica;
use Illuminate\Database\Seeder;

class CestaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $cestas = cesta::factory()
            ->has(sluzba::factory())
            ->has(ulica::factory())
            ->count(30)
            ->create();
    }
}
