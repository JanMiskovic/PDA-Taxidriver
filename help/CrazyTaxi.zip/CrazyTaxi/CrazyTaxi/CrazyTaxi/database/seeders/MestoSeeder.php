<?php

namespace Database\Seeders;

use App\Models\mesto;
use Illuminate\Database\Seeder;

class MestoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $mestos = mesto::factory()
            ->count(30)
            ->create();
    }
}
