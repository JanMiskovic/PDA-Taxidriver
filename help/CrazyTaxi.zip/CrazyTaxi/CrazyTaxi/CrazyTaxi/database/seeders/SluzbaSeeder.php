<?php

namespace Database\Seeders;

use App\Models\sluzba;
use App\Models\taxikar;
use App\Models\auto;
use Illuminate\Database\Seeder;

class SluzbaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $sluzbas = sluzba::factory()
            ->has(taxikar::factory())
            ->has(auto::factory())
            ->count(30)
            ->create();
    }
}
