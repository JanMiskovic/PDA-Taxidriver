<?php

namespace Database\Seeders;

use App\Models\taxikar;
use Illuminate\Database\Seeder;

class TaxikarSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $taxikars = taxikar::factory()
            ->count(30)
            ->create();
    }
}
