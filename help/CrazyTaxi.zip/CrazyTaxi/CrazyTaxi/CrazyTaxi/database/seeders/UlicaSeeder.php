<?php

namespace Database\Seeders;

use App\Models\ulica;
use App\Models\mesto;
use Illuminate\Database\Seeder;

class UlicaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $ulicas = ulica::factory()
            ->has(mesto::factory())
            ->count(30)
            ->create();
    }
}
