<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            AutoSeeder::class,
            TaxikarSeeder::class,
            MestoSeeder::class,
            UlicaSeeder::class,
            SluzbaSeeder::class,
            CestaSeeder::class,
        ]);
    }
}
