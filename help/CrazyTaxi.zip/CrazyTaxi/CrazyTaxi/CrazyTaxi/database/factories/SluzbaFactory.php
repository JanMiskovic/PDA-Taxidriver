<?php

namespace Database\Factories;

use App\Models\sluzba;
use App\Models\taxikar;
use App\Models\auto;
use Illuminate\Database\Eloquent\Factories\Factory;

class SluzbaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = sluzba::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'taxikar_id' => taxikar::factory(),
            'auto_id' => auto::factory(),
            'cas_od' => $this->faker->time(),
            'cas_do' => $this->faker->time(),
            'datum' => $this->faker->date(),
        ];
    }
}
