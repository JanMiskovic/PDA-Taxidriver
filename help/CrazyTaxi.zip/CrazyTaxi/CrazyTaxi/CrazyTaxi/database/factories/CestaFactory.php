<?php

namespace Database\Factories;

use App\Models\cesta;
use App\Models\sluzba;
use App\Models\ulica;
use Illuminate\Database\Eloquent\Factories\Factory;

class CestaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = cesta::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'sluzba_id' => sluzba::factory(),
            'start_ulica_id' => ulica::factory(),
            'koniec_ulica_id' => ulica::factory(),
            'cena' => $this->faker->randomFloat(2,2,20),
        ];
    }
}
