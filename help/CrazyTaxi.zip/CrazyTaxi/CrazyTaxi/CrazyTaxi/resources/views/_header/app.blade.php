<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <title>Crazy Taxi</title>
</head>

<nav class="navbar sticky-top navbar-expand navbar-light bg-warning" style="font-size: 20px !important; font-weight: bold;">
    <a class="navbar-brand" href="{{ url('/') }}">
        <img src="{{ asset('img/logo.png') }}" width="105" height="30" style="margin-left: 20px" alt="logo">
    </a>
    <div class="navbar" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="{{ route('sluzba.index') }}">Služby</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('cesta.index') }}">Cesty</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('taxikar.index') }}">Taxikári</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="{{ route('auto.index') }}">Autá</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('mesto.index') }}">Mestá</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('ulica.index') }}">Ulice</a>
            </li>
        </ul>
    </div>
</nav>
<body>
<div class="py-5 container">
    @yield('content')
</div>
</body>

</html>
