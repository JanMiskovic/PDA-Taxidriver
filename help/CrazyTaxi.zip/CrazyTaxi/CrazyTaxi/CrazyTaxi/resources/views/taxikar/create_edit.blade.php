@extends('_header.app')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-4">
            <form method="post" action="{{ $taxikar->exists ? route('taxikar.update', $taxikar->id) : route('taxikar.store') }}">
                @csrf
                @if($taxikar->exists)
                    @method('PATCH')
                @endif
                <div class="mb-3">
                    <label for="firstname" class="form-label">Meno</label>
                    <input value="{{ old('firstname', $taxikar->firstname) }}" type="text" name="firstname" class="form-control" id="firstname" required>
                </div>
                <div class="mb-3">
                    <label for="lastname" class="form-label">Priezvisko</label>
                    <input value="{{ old('lastname', $taxikar->lastname) }}" type="text" name="lastname" class="form-control" id="lastname" required>
                </div>
                <button class="btn btn-warning" type="submit">Uložiť</button>
            </form>
        </div>
    </div>
@endsection
