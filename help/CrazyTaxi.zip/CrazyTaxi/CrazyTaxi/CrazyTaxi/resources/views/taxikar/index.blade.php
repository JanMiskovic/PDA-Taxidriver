@extends('_header.app')

@section('content')
    <h1>Taxikári</h1>
    <a class="btn btn-lg btn-warning mb-3" href="{{ route('taxikar.create') }}">Nový záznam</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">Meno</th>
            <th scope="col">Priezvisko</th>
            <th scope="col">Akcie</th>
        </tr>
        </thead>
        <tbody>
        @foreach($taxikars as $taxikar)
            <tr>
                <th scope="row">{{ $taxikar->id }}</th>
                <td scope="row">{{ $taxikar->firstname }}</td>
                <td scope="row">{{ $taxikar->lastname }}</td>

                <td>
                    <a class="btn btn-sm btn-outline-primary" href="{{ route('taxikar.edit', $taxikar->id) }}">Upraviť</a>
                    <form class="d-inline-block" method="post" action="{{ route('taxikar.destroy', $taxikar->id) }}">
                        @csrf
                        @method('delete')
                        <button type="submit" class="btn btn-sm btn-outline-danger">Vymazať</button>
                    </form>
                    <a class="btn btn-sm btn-outline-success" href="{{ route('taxikar.show', $taxikar->id) }}">Info</a>
                </td>
            </tr>
        @endforeach

        </tbody>
    </table>
@endsection
