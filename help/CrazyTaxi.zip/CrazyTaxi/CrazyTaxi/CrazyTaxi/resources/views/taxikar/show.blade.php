@extends('_header.app')

@section('content')
    <div class="row justify-content-center">
            @if($taxikar->exists)
            <div class="mb-3">
                <h1>Info pre {{$taxikar->firstname}} {{$taxikar->lastname}}</h1>
                <code>
                    id: {{ $taxikar->id }}<br>
                    firstname: {{ $taxikar->firstname }}<br>
                    lastname: {{ $taxikar->lastname }}<br>
                    created_at: {{ $taxikar->created_at }}<br>
                    updated_at: {{ $taxikar->updated_at }}
                </code>
            </div>
            @endif
    </div>
@endsection
