@extends('_header.app')

@section('content')
    <h1>Mestá</h1>
    <a class="btn btn-lg btn-warning mb-3" href="{{ route('mesto.create') }}">Nový záznam</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">Nazov</th>
            <th scope="col">Akcie</th>
        </tr>
        </thead>
        <tbody>
        @foreach($mestos as $mesto)
            <tr>
                <th scope="row">{{ $mesto->id }}</th>
                <td scope="row">{{ $mesto->name }}</td>

                <td>
                    <a class="btn btn-sm btn-outline-primary" href="{{ route('mesto.edit', $mesto->id) }}">Upraviť</a>
                    <form class="d-inline-block" method="post" action="{{ route('mesto.destroy', $mesto->id) }}">
                        @csrf
                        @method('delete')
                        <button type="submit" class="btn btn-sm btn-outline-danger">Vymazať</button>
                    </form>
                    <a class="btn btn-sm btn-outline-success" href="{{ route('mesto.show', $mesto->id) }}">Info</a>
                </td>
            </tr>
        @endforeach

        </tbody>
    </table>
@endsection
