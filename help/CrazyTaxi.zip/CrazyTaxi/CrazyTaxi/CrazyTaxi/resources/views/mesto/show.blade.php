@extends('_header.app')

@section('content')
    <div class="row justify-content-center">
            @if($mesto->exists)
            <div class="mb-3">
                <h1>Info pre {{$mesto->name}}</h1>
                <code>
                    id: {{ $mesto->id }}<br>
                    name: {{ $mesto->name }}<br>
                    created_at: {{ $mesto->created_at }}<br>
                    updated_at: {{ $mesto->updated_at }}
                </code>
            </div>
            @endif
    </div>
@endsection
