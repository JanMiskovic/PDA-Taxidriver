@extends('_header.app')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-4">
            <form method="post" action="{{ $mesto->exists ? route('mesto.update', $mesto->id) : route('mesto.store') }}">
                @csrf
                @if($mesto->exists)
                    @method('PATCH')
                @endif
                <div class="mb-3">
                    <label for="name" class="form-label">Nazov</label>
                    <input value="{{ old('name', $mesto->name) }}" type="text" name="name" class="form-control" id="name" required>
                </div>
                <button class="btn btn-warning" type="submit">Uložiť</button>
            </form>
        </div>
    </div>
@endsection
