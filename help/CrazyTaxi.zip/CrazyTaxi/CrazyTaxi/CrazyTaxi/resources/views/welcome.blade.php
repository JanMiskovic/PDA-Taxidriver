@extends('_header.app')

@section('content')
    <center>
        <img src="{{ asset('img/logo.png') }}" alt="logo">
        <h1>Databáza pre taxi službu</h1>
        <br>
        <a class="btn btn-warning" href="{{ route('sluzba.index') }}">Služby</a>
        <a class="btn btn-warning" href="{{ route('cesta.index') }}">Cesty</a>
        <a class="btn btn-warning" href="{{ route('taxikar.index') }}">Taxikári</a>
        <a class="btn btn-warning" href="{{ route('auto.index') }}">Autá</a>
        <a class="btn btn-warning" href="{{ route('mesto.index') }}">Mestá</a>
        <a class="btn btn-warning" href="{{ route('ulica.index') }}">Ulice</a>

    </center>
@endsection
