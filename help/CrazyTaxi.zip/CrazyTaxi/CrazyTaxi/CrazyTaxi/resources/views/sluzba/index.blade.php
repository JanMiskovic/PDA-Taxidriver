@extends('_header.app')

@section('content')
    <h1>Služby</h1>
    <a class="btn btn-lg btn-warning mb-3" href="{{ route('sluzba.create') }}">Nový záznam</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">Taxikar</th>
            <th scope="col">Auto</th>
            <th scope="col">Od</th>
            <th scope="col">Do</th>
            <th scope="col">Dátum</th>
            <th scope="col">Akcie</th>
        </tr>
        </thead>
        <tbody>
        @foreach($sluzbas as $sluzba)
            <tr>
                <th scope="row">{{ $sluzba->id }}</th>
                <td>
                    @if($sluzba->taxikar_id !== null)
                        {{ $sluzba->taxikar->firstname}}
                        {{ $sluzba->taxikar->lastname}}
                    @endif
                </td>
                <td>
                    @if($sluzba->auto_id !== null)
                        {{ $sluzba->auto->name}} ({{ $sluzba->auto->evidencne_cislo}})
                    @endif
                </td>
                <td>{{ $sluzba->cas_od}}</td>
                <td>{{ $sluzba->cas_do}}</td>
                <td>{{ $sluzba->datum}}</td>
                <td>

                    <a class="btn btn-sm btn-outline-primary" href="{{ route('sluzba.edit', $sluzba->id) }}">Upraviť</a>
                    <form class="d-inline-block" method="post" action="{{ route('sluzba.destroy', $sluzba->id) }}">
                        @csrf
                        @method('delete')
                        <button type="submit" class="btn btn-sm btn-outline-danger">Vymazať</button>
                    </form>
                    <a class="btn btn-sm btn-outline-success" href="{{ route('sluzba.show', $sluzba->id) }}">Info</a>
                </td>
            </tr>
        @endforeach

        </tbody>
    </table>
@endsection
