@extends('_header.app')

@section('content')
    <div class="row justify-content-center">
            @if($sluzba->exists)
            <div class="mb-3">
                <h1>Info pre id {{$sluzba->id}}</h1>
                <code>
                    id: {{ $sluzba->id }}<br>
                    taxikar_id: {{ $sluzba->taxikar_id }} ({{ $sluzba->taxikar->firstname }} {{ $sluzba->taxikar->lastname }})<br>
                    auto_id: {{ $sluzba->auto_id }} ({{ $sluzba->auto->name }}; {{ $sluzba->auto->evidencne_cislo }})<br>
                    cas_od: {{ $sluzba->cas_od }}<br>
                    cas_do: {{ $sluzba->cas_do }}<br>
                    datum: {{ $sluzba->datum }}<br>
                    created_at: {{ $sluzba->created_at }}<br>
                    updated_at: {{ $sluzba->updated_at }}
                </code>
            </div>
            @endif
    </div>
@endsection
