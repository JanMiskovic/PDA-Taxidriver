@extends('_header.app')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-4">
            <form method="post" action="{{ $sluzba->exists ? route('sluzba.update', $sluzba->id) : route('sluzba.store') }}">
                @csrf
                @if($sluzba->exists)
                    @method('PATCH')
                @endif

                <div class="mb-3">
                    <label for="taxikar_id" class="form-label">Taxikár</label>
                    <select id="taxikar_id" name="taxikar_id" class="form-select form-select-lg mb-3" required>
                        @unless($sluzba->exists)
                            <option selected></option>
                        @endunless
                        @foreach($taxikars as $taxikar)
                            <option value="{{ $taxikar->id }}"{{ $taxikar->id === old('taxikar_id', $sluzba->taxikar->id ?? '') ? ' selected' : '' }}>
                                {{ $taxikar->firstname }} {{ $taxikar->lastname }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label for="auto_id" class="form-label">Auto</label>
                    <select id="auto_id" name="auto_id" class="form-select form-select-lg mb-3" required>
                        @unless($sluzba->exists)
                            <option selected></option>
                        @endunless
                        @foreach($autos as $auto)
                            <option value="{{ $auto->id }}"{{ $auto->id === old('auto_id', $sluzba->auto->id ?? '') ? ' selected' : '' }}>
                                {{ $auto->name }} ({{ $auto->evidencne_cislo }})
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label for="cas_od" class="form-label">Od</label>
                    <input type="time" value="{{ old('cas_od', $sluzba->cas_od) }}" name="cas_od" class="form-control" id="cas_od" required>
                </div>
                <div class="mb-3">
                    <label for="cas_do" class="form-label">Dd</label>
                    <input type="time" value="{{ old('cas_do', $sluzba->cas_do) }}" name="cas_do" class="form-control" id="cas_do" required>
                </div>
                <div class="mb-3">
                    <label for="datum" class="form-label">Dátum</label>
                    <input type="date" value="{{ old('datum', $sluzba->datum) }}" name="datum" class="form-control" id="datum" required>
                </div>

                <button class="btn btn-warning" type="submit">Uložiť</button>
            </form>
        </div>
    </div>
@endsection
