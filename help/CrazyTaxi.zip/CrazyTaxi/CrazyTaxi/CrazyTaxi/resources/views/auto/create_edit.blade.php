@extends('_header.app')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-4">
            <form method="post" action="{{ $auto->exists ? route('auto.update', $auto->id) : route('auto.store') }}">
                @csrf
                @if($auto->exists)
                    @method('PATCH')
                @endif
                <div class="mb-3">
                    <label for="name" class="form-label">Názov</label>
                    <input value="{{ old('firstname', $auto->name) }}" type="text" name="name" class="form-control" id="name" required>
                </div>
                <div class="mb-3">
                    <label for="evidencne_cislo" class="form-label">Evidenčné číslo</label>
                    <input value="{{ old('lastname', $auto->evidencne_cislo) }}" type="text" name="evidencne_cislo" class="form-control" id="evidencne_cislo" required>
                </div>
                <button class="btn btn-warning" type="submit">Uložiť</button>
            </form>
        </div>
    </div>
@endsection
