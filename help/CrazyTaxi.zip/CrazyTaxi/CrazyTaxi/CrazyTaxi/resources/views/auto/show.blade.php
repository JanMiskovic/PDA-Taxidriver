@extends('_header.app')

@section('content')
    <div class="row justify-content-center">
            @if($auto->exists)
            <div class="mb-3">
                <h1>Info pre {{$auto->name}}; {{$auto->evidencne_cislo}}</h1>
                <code>
                    id: {{ $auto->id }}<br>
                    name: {{ $auto->name }}<br>
                    evidencne_cislo: {{ $auto->evidencne_cislo }}<br>
                    created_at: {{ $auto->created_at }}<br>
                    updated_at: {{ $auto->updated_at }}
                </code>
            </div>
            @endif
    </div>
@endsection
