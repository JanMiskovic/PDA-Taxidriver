@extends('_header.app')

@section('content')
    <h1>Autá</h1>
    <a class="btn btn-lg btn-warning mb-3" href="{{ route('auto.create') }}">Nový záznam</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">Názov</th>
            <th scope="col">Evidenčné číslo</th>
            <th scope="col">Akcie</th>
        </tr>
        </thead>
        <tbody>
        @foreach($autos as $auto)
            <tr>
                <th scope="row">{{ $auto->id }}</th>
                <td scope="row">{{ $auto->name }}</td>
                <td scope="row">{{ $auto->evidencne_cislo }}</td>

                <td>
                    <a class="btn btn-sm btn-outline-primary" href="{{ route('auto.edit', $auto->id) }}">Upraviť</a>
                    <form class="d-inline-block" method="post" action="{{ route('auto.destroy', $auto->id) }}">
                        @csrf
                        @method('delete')
                        <button type="submit" class="btn btn-sm btn-outline-danger">Vymazať</button>
                    </form>
                    <a class="btn btn-sm btn-outline-success" href="{{ route('auto.show', $auto->id) }}">Info</a>
                </td>
            </tr>
        @endforeach

        </tbody>
    </table>
@endsection
