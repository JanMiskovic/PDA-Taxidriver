@extends('_header.app')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-4">
            <form method="post" action="{{ $cesta->exists ? route('cesta.update', $cesta->id) : route('cesta.store') }}">
                @csrf
                @if($cesta->exists)
                    @method('PATCH')
                @endif

                <div class="mb-3">
                    <label for="sluzba_id" class="form-label">Služba</label>
                    <select id="sluzba_id" name="sluzba_id" class="form-select form-select-lg mb-3" required>
                        @unless($cesta->exists)
                            <option selected></option>
                        @endunless
                        @foreach($sluzbas as $sluzba)
                            <option value="{{ $sluzba->id }}"{{ $sluzba->id === old('sluzba_id', $cesta->sluzba->id ?? '') ? ' selected' : '' }}>
                                {{ $sluzba->taxikar->firstname }} {{ $sluzba->taxikar->lastname }} - {{ $sluzba->datum }} ({{ $sluzba->cas_od }} - {{ $sluzba->cas_do }})
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label for="start_ulica_id" class="form-label">Počiatočná ulica</label>
                    <select id="start_ulica_id" name="start_ulica_id" class="form-select form-select-lg mb-3" required>
                        @unless($cesta->exists)
                            <option selected></option>
                        @endunless
                        @foreach($ulicas as $ulica)
                            <option value="{{ $ulica->id }}"{{ $ulica->id === old('ulica_id', $cesta->ulica->id ?? '') ? ' selected' : '' }}>
                                {{ $ulica->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label for="koniec_ulica_id" class="form-label">Konečná ulica</label>
                    <select id="koniec_ulica_id" name="koniec_ulica_id" class="form-select form-select-lg mb-3" required>
                        @unless($cesta->exists)
                            <option selected></option>
                        @endunless
                        @foreach($ulicas as $ulica)
                            <option value="{{ $ulica->id }}"{{ $ulica->id === old('ulica_id', $cesta->ulica->id ?? '') ? ' selected' : '' }}>
                                {{ $ulica->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label for="cena" class="form-label">Cena</label>
                    <input type="number" step=".01" value="{{ old('cena', $cesta->cena) }}" name="cena" class="form-control" id="cena" required>
                </div>

                <button class="btn btn-warning" type="submit">Uložiť</button>
            </form>
        </div>
    </div>
@endsection
