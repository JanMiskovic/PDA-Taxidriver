@extends('_header.app')

@section('content')
    <div class="row justify-content-center">
            @if($cesta->exists)
            <div class="mb-3">
                <h1>Info pre id {{$cesta->id}}</h1>
                <code>
                    id: {{ $cesta->id }}<br>
                    sluzba_id: {{ $cesta->sluzba_id }}<br>
                    start_ulica_id: {{ $cesta->start_ulica_id }}<br>
                    koniec_ulica_id: {{ $cesta->koniec_ulica_id }}<br>
                    cena: {{ $cesta->cena }}<br>
                    created_at: {{ $cesta->created_at }}<br>
                    updated_at: {{ $cesta->updated_at }}
                </code>
            </div>
            @endif
    </div>
@endsection
