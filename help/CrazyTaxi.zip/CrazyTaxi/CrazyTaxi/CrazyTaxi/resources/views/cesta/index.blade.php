@extends('_header.app')

@section('content')
    <h1>Cesty</h1>
    <a class="btn btn-lg btn-warning mb-3" href="{{ route('cesta.create') }}">Nový záznam</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">Služba</th>
            <th scope="col">Počiatočná ulica</th>
            <th scope="col">Konečná ulica</th>
            <th scope="col">Cena</th>
            <th scope="col">Kedy</th>
            <th scope="col">Akcie</th>
        </tr>
        </thead>
        <tbody>
        @foreach($cestas as $cesta)
            <tr>
                <th scope="row">{{ $cesta->id }}</th>
                <td>
                    @if($cesta->sluzba_id !== null)
                        <b>{{ $cesta->sluzba->taxikar->firstname }} {{ $cesta->sluzba->taxikar->lastname }}</b><br>{{ $cesta->sluzba->datum }}
                    @endif
                </td>
                <td>
                    @if($cesta->start_ulica_id !== null)
                        {{ $cesta->start_ulica->name }}<br><i>{{ $cesta->start_ulica->mesto->name }}</i>
                    @endif
                </td>
                <td>
                    @if($cesta->koniec_ulica_id !== null)
                        {{ $cesta->koniec_ulica->name }}<br><i>{{ $cesta->start_ulica->mesto->name }}</i>
                    @endif
                </td>
                <td>{{ $cesta->cena}}€</td>
                <td>{{ $cesta->created_at}}</td>
                <td>
                    <a class="btn btn-sm btn-outline-primary" href="{{ route('cesta.edit', $cesta->id) }}">Upraviť</a>
                    <form class="d-inline-block" method="post" action="{{ route('cesta.destroy', $cesta->id) }}">
                        @csrf
                        @method('delete')
                        <button type="submit" class="btn btn-sm btn-outline-danger">Vymazať</button>
                    </form>
                    <a class="btn btn-sm btn-outline-success" href="{{ route('cesta.show', $cesta->id) }}">Info</a>
                </td>
            </tr>
        @endforeach

        </tbody>
    </table>
@endsection
