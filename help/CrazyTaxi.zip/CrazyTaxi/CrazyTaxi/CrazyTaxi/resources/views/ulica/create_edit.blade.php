@extends('_header.app')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-4">
            <form method="post" action="{{ $ulica->exists ? route('ulica.update', $ulica->id) : route('ulica.store') }}">
                @csrf
                @if($ulica->exists)
                    @method('PATCH')
                @endif
                <div class="mb-3">
                    <label for="name" class="form-label">Nazov</label>
                    <input value="{{ old('name', $ulica->name) }}" type="text" name="name" class="form-control" id="firstname" required>
                </div>

                <div class="mb-3">
                    <label for="mesto_id" class="form-label">Mesto</label>
                    <select id="mesto_id" name="mesto_id" class="form-select form-select-lg mb-3" required>
                        @unless($ulica->exists)
                            <option selected></option>
                        @endunless
                        @foreach($mestos as $mesto)
                            <option value="{{ $mesto->id }}"{{ $mesto->id === old('mesto_id', $ulica->mesto->id ?? '') ? ' selected' : '' }}>
                                {{ $mesto->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <button class="btn btn-warning" type="submit">Uložiť</button>
            </form>
        </div>
    </div>
@endsection
