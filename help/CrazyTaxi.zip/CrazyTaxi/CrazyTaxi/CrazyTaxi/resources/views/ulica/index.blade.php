@extends('_header.app')

@section('content')
    <h1>Ulice</h1>
    <a class="btn btn-lg btn-warning mb-3" href="{{ route('ulica.create') }}">Nový záznam</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">Nazov</th>
            <th scope="col">Mesto</th>
            <th scope="col">Akcie</th>
        </tr>
        </thead>
        <tbody>
        @foreach($ulicas as $ulica)
            <tr>
                <th scope="row">{{ $ulica->id }}</th>
                <td scope="row">{{ $ulica->name }}</td>
                <td scope="row">{{ $ulica->mesto->name }}</td>

                <td>
                    <a class="btn btn-sm btn-outline-primary" href="{{ route('ulica.edit', $ulica->id) }}">Upraviť</a>
                    <form class="d-inline-block" method="post" action="{{ route('ulica.destroy', $ulica->id) }}">
                        @csrf
                        @method('delete')
                        <button type="submit" class="btn btn-sm btn-outline-danger">Vymazať</button>
                    </form>
                    <a class="btn btn-sm btn-outline-success" href="{{ route('ulica.show', $ulica->id) }}">Info</a>
                </td>
            </tr>
        @endforeach

        </tbody>
    </table>
@endsection
