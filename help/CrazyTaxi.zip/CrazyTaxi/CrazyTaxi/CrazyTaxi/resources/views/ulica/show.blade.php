@extends('_header.app')

@section('content')
    <div class="row justify-content-center">
            @if($ulica->exists)
            <div class="mb-3">
                <h1>Info pre {{$ulica->name}}</h1>
                <code>
                    id: {{ $ulica->id }}<br>
                    name: {{ $ulica->name }}<br>
                    mesto_id: {{ $ulica->mesto_id }} ({{ $ulica->mesto->name }})<br>
                    created_at: {{ $ulica->created_at }}<br>
                    updated_at: {{ $ulica->updated_at }}
                </code>
            </div>
            @endif
    </div>
@endsection
