<?php $__env->startSection('content'); ?>
    <center>
        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="logo">
        <h1>Databáza pre taxi službu</h1>
        <br>
        <a class="btn btn-warning" href="<?php echo e(route('sluzba.index')); ?>">Služby</a>
        <a class="btn btn-warning" href="<?php echo e(route('cesta.index')); ?>">Cesty</a>
        <a class="btn btn-warning" href="<?php echo e(route('taxikar.index')); ?>">Taxikári</a>
        <a class="btn btn-warning" href="<?php echo e(route('auto.index')); ?>">Autá</a>
        <a class="btn btn-warning" href="<?php echo e(route('mesto.index')); ?>">Mestá</a>
        <a class="btn btn-warning" href="<?php echo e(route('ulica.index')); ?>">Ulice</a>

    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/welcome.blade.php ENDPATH**/ ?>