<?php $__env->startSection('content'); ?>
    <h1>Autá</h1>
    <a class="btn btn-lg btn-warning mb-3" href="<?php echo e(route('auto.create')); ?>">Nový záznam</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">Názov</th>
            <th scope="col">Evidenčné číslo</th>
            <th scope="col">Akcie</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $autos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($auto->id); ?></th>
                <td scope="row"><?php echo e($auto->name); ?></td>
                <td scope="row"><?php echo e($auto->evidencne_cislo); ?></td>

                <td>
                    <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('auto.edit', $auto->id)); ?>">Upraviť</a>
                    <form class="d-inline-block" method="post" action="<?php echo e(route('auto.destroy', $auto->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger">Vymazať</button>
                    </form>
                    <a class="btn btn-sm btn-outline-success" href="<?php echo e(route('auto.show', $auto->id)); ?>">Info</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/auto/index.blade.php ENDPATH**/ ?>