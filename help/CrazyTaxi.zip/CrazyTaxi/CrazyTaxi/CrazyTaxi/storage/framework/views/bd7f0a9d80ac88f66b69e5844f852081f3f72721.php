<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
            <?php if($mesto->exists): ?>
            <div class="mb-3">
                <h1>Info pre <?php echo e($mesto->name); ?></h1>
                <code>
                    id: <?php echo e($mesto->id); ?><br>
                    name: <?php echo e($mesto->name); ?><br>
                    created_at: <?php echo e($mesto->created_at); ?><br>
                    updated_at: <?php echo e($mesto->updated_at); ?>

                </code>
            </div>
            <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/mesto/show.blade.php ENDPATH**/ ?>