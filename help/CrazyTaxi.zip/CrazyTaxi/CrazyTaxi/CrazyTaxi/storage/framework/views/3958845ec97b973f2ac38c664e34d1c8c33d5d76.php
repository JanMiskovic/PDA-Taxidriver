<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-4">
            <form method="post" action="<?php echo e($sluzba->exists ? route('sluzba.update', $sluzba->id) : route('sluzba.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php if($sluzba->exists): ?>
                    <?php echo method_field('PATCH'); ?>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="taxikar_id" class="form-label">Taxikár</label>
                    <select id="taxikar_id" name="taxikar_id" class="form-select form-select-lg mb-3" required>
                        <?php if (! ($sluzba->exists)): ?>
                            <option selected></option>
                        <?php endif; ?>
                        <?php $__currentLoopData = $taxikars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taxikar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($taxikar->id); ?>"<?php echo e($taxikar->id === old('taxikar_id', $sluzba->taxikar->id ?? '') ? ' selected' : ''); ?>>
                                <?php echo e($taxikar->firstname); ?> <?php echo e($taxikar->lastname); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="auto_id" class="form-label">Auto</label>
                    <select id="auto_id" name="auto_id" class="form-select form-select-lg mb-3" required>
                        <?php if (! ($sluzba->exists)): ?>
                            <option selected></option>
                        <?php endif; ?>
                        <?php $__currentLoopData = $autos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($auto->id); ?>"<?php echo e($auto->id === old('auto_id', $sluzba->auto->id ?? '') ? ' selected' : ''); ?>>
                                <?php echo e($auto->name); ?> (<?php echo e($auto->evidencne_cislo); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="cas_od" class="form-label">Od</label>
                    <input type="time" value="<?php echo e(old('cas_od', $sluzba->cas_od)); ?>" name="cas_od" class="form-control" id="cas_od" required>
                </div>
                <div class="mb-3">
                    <label for="cas_do" class="form-label">Dd</label>
                    <input type="time" value="<?php echo e(old('cas_do', $sluzba->cas_do)); ?>" name="cas_do" class="form-control" id="cas_do" required>
                </div>
                <div class="mb-3">
                    <label for="datum" class="form-label">Dátum</label>
                    <input type="date" value="<?php echo e(old('datum', $sluzba->datum)); ?>" name="datum" class="form-control" id="datum" required>
                </div>

                <button class="btn btn-warning" type="submit">Uložiť</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/sluzba/create_edit.blade.php ENDPATH**/ ?>