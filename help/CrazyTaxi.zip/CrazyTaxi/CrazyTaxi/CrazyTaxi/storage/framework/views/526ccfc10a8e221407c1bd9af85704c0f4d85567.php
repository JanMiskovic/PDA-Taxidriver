<?php $__env->startSection('content'); ?>
    <h1>Ulice</h1>
    <a class="btn btn-lg btn-warning mb-3" href="<?php echo e(route('ulica.create')); ?>">Nový záznam</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">Nazov</th>
            <th scope="col">Mesto</th>
            <th scope="col">Akcie</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $ulicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ulica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($ulica->id); ?></th>
                <td scope="row"><?php echo e($ulica->name); ?></td>
                <td scope="row"><?php echo e($ulica->mesto->name); ?></td>

                <td>
                    <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('ulica.edit', $ulica->id)); ?>">Upraviť</a>
                    <form class="d-inline-block" method="post" action="<?php echo e(route('ulica.destroy', $ulica->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger">Vymazať</button>
                    </form>
                    <a class="btn btn-sm btn-outline-success" href="<?php echo e(route('ulica.show', $ulica->id)); ?>">Info</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/ulica/index.blade.php ENDPATH**/ ?>