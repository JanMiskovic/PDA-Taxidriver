<?php $__env->startSection('content'); ?>
    <h1>Služby</h1>
    <a class="btn btn-lg btn-warning mb-3" href="<?php echo e(route('sluzba.create')); ?>">Nový záznam</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">Taxikar</th>
            <th scope="col">Auto</th>
            <th scope="col">Od</th>
            <th scope="col">Do</th>
            <th scope="col">Dátum</th>
            <th scope="col">Akcie</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $sluzbas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sluzba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($sluzba->id); ?></th>
                <td>
                    <?php if($sluzba->taxikar_id !== null): ?>
                        <?php echo e($sluzba->taxikar->firstname); ?>

                        <?php echo e($sluzba->taxikar->lastname); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($sluzba->auto_id !== null): ?>
                        <?php echo e($sluzba->auto->name); ?> (<?php echo e($sluzba->auto->evidencne_cislo); ?>)
                    <?php endif; ?>
                </td>
                <td><?php echo e($sluzba->cas_od); ?></td>
                <td><?php echo e($sluzba->cas_do); ?></td>
                <td><?php echo e($sluzba->datum); ?></td>
                <td>

                    <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('sluzba.edit', $sluzba->id)); ?>">Upraviť</a>
                    <form class="d-inline-block" method="post" action="<?php echo e(route('sluzba.destroy', $sluzba->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger">Vymazať</button>
                    </form>
                    <a class="btn btn-sm btn-outline-success" href="<?php echo e(route('sluzba.show', $sluzba->id)); ?>">Info</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/sluzba/index.blade.php ENDPATH**/ ?>