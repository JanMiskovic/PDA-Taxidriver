<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <title>Crazy Taxi</title>
</head>
<nav class="navbar navbar-light bg-light">
    <a class="navbar-brand" href="#">
        <img src="<?php echo e(asset('img/logo.png')); ?>" width="120" height="30" style="margin-left: 20px" alt="logo">
    </a>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="#">Študenti</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Fakulty</a>
            </li>
        </ul>
    </div>
</nav>
<body>
<div class="py-5 container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/_header/app.blade.php ENDPATH**/ ?>
