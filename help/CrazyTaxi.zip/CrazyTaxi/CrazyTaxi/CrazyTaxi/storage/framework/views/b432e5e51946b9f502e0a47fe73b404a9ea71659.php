<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
            <?php if($taxikar->exists): ?>
            <div class="mb-3">
                <h1>Info pre <?php echo e($taxikar->firstname); ?> <?php echo e($taxikar->lastname); ?></h1>
                <code>
                    id: <?php echo e($taxikar->id); ?><br>
                    firstname: <?php echo e($taxikar->firstname); ?><br>
                    lastname: <?php echo e($taxikar->lastname); ?><br>
                    created_at: <?php echo e($taxikar->created_at); ?><br>
                    updated_at: <?php echo e($taxikar->updated_at); ?>

                </code>
            </div>
            <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/taxikar/show.blade.php ENDPATH**/ ?>