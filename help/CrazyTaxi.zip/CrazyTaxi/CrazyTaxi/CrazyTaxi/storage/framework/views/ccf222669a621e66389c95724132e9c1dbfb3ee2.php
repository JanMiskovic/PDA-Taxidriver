<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
            <?php if($ulica->exists): ?>
            <div class="mb-3">
                <h1>Info pre <?php echo e($ulica->name); ?></h1>
                <code>
                    id: <?php echo e($ulica->id); ?><br>
                    name: <?php echo e($ulica->name); ?><br>
                    mesto_id: <?php echo e($ulica->mesto_id); ?> (<?php echo e($ulica->mesto->name); ?>)<br>
                    created_at: <?php echo e($ulica->created_at); ?><br>
                    updated_at: <?php echo e($ulica->updated_at); ?>

                </code>
            </div>
            <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/ulica/show.blade.php ENDPATH**/ ?>