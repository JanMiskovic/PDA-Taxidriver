<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-4">
            <form method="post" action="<?php echo e($taxikar->exists ? route('taxikar.update', $taxikar->id) : route('taxikar.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php if($taxikar->exists): ?>
                    <?php echo method_field('PATCH'); ?>
                <?php endif; ?>
                <div class="mb-3">
                    <label for="firstname" class="form-label">Meno</label>
                    <input value="<?php echo e(old('firstname', $taxikar->firstname)); ?>" type="text" name="firstname" class="form-control" id="firstname" required>
                </div>
                <div class="mb-3">
                    <label for="lastname" class="form-label">Priezvisko</label>
                    <input value="<?php echo e(old('lastname', $taxikar->lastname)); ?>" type="text" name="lastname" class="form-control" id="lastname" required>
                </div>
                <button class="btn btn-warning" type="submit">Uložiť</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/taxikar/create_edit.blade.php ENDPATH**/ ?>