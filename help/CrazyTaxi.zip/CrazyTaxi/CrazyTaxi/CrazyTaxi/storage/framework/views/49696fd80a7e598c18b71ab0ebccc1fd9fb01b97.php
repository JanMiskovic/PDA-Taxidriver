<?php $__env->startSection('content'); ?>
    <h1>Cesty</h1>
    <a class="btn btn-lg btn-warning mb-3" href="<?php echo e(route('cesta.create')); ?>">Nový záznam</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">Služba</th>
            <th scope="col">Počiatočná ulica</th>
            <th scope="col">Konečná ulica</th>
            <th scope="col">Cena</th>
            <th scope="col">Kedy</th>
            <th scope="col">Akcie</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $cestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($cesta->id); ?></th>
                <td>
                    <?php if($cesta->sluzba_id !== null): ?>
                        <b><?php echo e($cesta->sluzba->taxikar->firstname); ?> <?php echo e($cesta->sluzba->taxikar->lastname); ?></b><br><?php echo e($cesta->sluzba->datum); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($cesta->start_ulica_id !== null): ?>
                        <?php echo e($cesta->start_ulica->name); ?><br><i><?php echo e($cesta->start_ulica->mesto->name); ?></i>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($cesta->koniec_ulica_id !== null): ?>
                        <?php echo e($cesta->koniec_ulica->name); ?><br><i><?php echo e($cesta->start_ulica->mesto->name); ?></i>
                    <?php endif; ?>
                </td>
                <td><?php echo e($cesta->cena); ?>€</td>
                <td><?php echo e($cesta->created_at); ?></td>
                <td>
                    <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('cesta.edit', $cesta->id)); ?>">Upraviť</a>
                    <form class="d-inline-block" method="post" action="<?php echo e(route('cesta.destroy', $cesta->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger">Vymazať</button>
                    </form>
                    <a class="btn btn-sm btn-outline-success" href="<?php echo e(route('cesta.show', $cesta->id)); ?>">Info</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/cesta/index.blade.php ENDPATH**/ ?>