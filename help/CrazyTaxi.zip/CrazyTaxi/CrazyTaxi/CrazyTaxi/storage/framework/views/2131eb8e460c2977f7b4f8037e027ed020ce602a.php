<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
            <?php if($sluzba->exists): ?>
            <div class="mb-3">
                <h1>Info pre id <?php echo e($sluzba->id); ?></h1>
                <code>
                    id: <?php echo e($sluzba->id); ?><br>
                    taxikar_id: <?php echo e($sluzba->taxikar_id); ?> (<?php echo e($sluzba->taxikar->firstname); ?> <?php echo e($sluzba->taxikar->lastname); ?>)<br>
                    auto_id: <?php echo e($sluzba->auto_id); ?> (<?php echo e($sluzba->auto->name); ?>; <?php echo e($sluzba->auto->evidencne_cislo); ?>)<br>
                    cas_od: <?php echo e($sluzba->cas_od); ?><br>
                    cas_do: <?php echo e($sluzba->cas_do); ?><br>
                    datum: <?php echo e($sluzba->datum); ?><br>
                    created_at: <?php echo e($sluzba->created_at); ?><br>
                    updated_at: <?php echo e($sluzba->updated_at); ?>

                </code>
            </div>
            <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/sluzba/show.blade.php ENDPATH**/ ?>