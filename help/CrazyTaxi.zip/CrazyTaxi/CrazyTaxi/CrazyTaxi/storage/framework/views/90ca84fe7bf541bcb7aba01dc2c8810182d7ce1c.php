<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
            <?php if($cesta->exists): ?>
            <div class="mb-3">
                <h1>Info pre id <?php echo e($cesta->id); ?></h1>
                <code>
                    id: <?php echo e($cesta->id); ?><br>
                    sluzba_id: <?php echo e($cesta->sluzba_id); ?><br>
                    start_ulica_id: <?php echo e($cesta->start_ulica_id); ?><br>
                    koniec_ulica_id: <?php echo e($cesta->koniec_ulica_id); ?><br>
                    cena: <?php echo e($cesta->cena); ?><br>
                    created_at: <?php echo e($cesta->created_at); ?><br>
                    updated_at: <?php echo e($cesta->updated_at); ?>

                </code>
            </div>
            <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/cesta/show.blade.php ENDPATH**/ ?>