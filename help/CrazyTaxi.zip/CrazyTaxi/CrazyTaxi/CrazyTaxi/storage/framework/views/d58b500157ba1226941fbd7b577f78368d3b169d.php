<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
            <?php if($auto->exists): ?>
            <div class="mb-3">
                <h1>Info pre <?php echo e($auto->name); ?>; <?php echo e($auto->evidencne_cislo); ?></h1>
                <code>
                    id: <?php echo e($auto->id); ?><br>
                    name: <?php echo e($auto->name); ?><br>
                    evidencne_cislo: <?php echo e($auto->evidencne_cislo); ?><br>
                    created_at: <?php echo e($auto->created_at); ?><br>
                    updated_at: <?php echo e($auto->updated_at); ?>

                </code>
            </div>
            <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/auto/show.blade.php ENDPATH**/ ?>