<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-4">
            <form method="post" action="<?php echo e($auto->exists ? route('auto.update', $auto->id) : route('auto.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php if($auto->exists): ?>
                    <?php echo method_field('PATCH'); ?>
                <?php endif; ?>
                <div class="mb-3">
                    <label for="name" class="form-label">Názov</label>
                    <input value="<?php echo e(old('firstname', $auto->name)); ?>" type="text" name="name" class="form-control" id="name" required>
                </div>
                <div class="mb-3">
                    <label for="evidencne_cislo" class="form-label">Evidenčné číslo</label>
                    <input value="<?php echo e(old('lastname', $auto->evidencne_cislo)); ?>" type="text" name="evidencne_cislo" class="form-control" id="evidencne_cislo" required>
                </div>
                <button class="btn btn-warning" type="submit">Uložiť</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/auto/create_edit.blade.php ENDPATH**/ ?>