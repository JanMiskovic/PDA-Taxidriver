<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-4">
            <form method="post" action="<?php echo e($cesta->exists ? route('cesta.update', $cesta->id) : route('cesta.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php if($cesta->exists): ?>
                    <?php echo method_field('PATCH'); ?>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="sluzba_id" class="form-label">Služba</label>
                    <select id="sluzba_id" name="sluzba_id" class="form-select form-select-lg mb-3" required>
                        <?php if (! ($cesta->exists)): ?>
                            <option selected></option>
                        <?php endif; ?>
                        <?php $__currentLoopData = $sluzbas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sluzba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sluzba->id); ?>"<?php echo e($sluzba->id === old('sluzba_id', $cesta->sluzba->id ?? '') ? ' selected' : ''); ?>>
                                <?php echo e($sluzba->taxikar->firstname); ?> <?php echo e($sluzba->taxikar->lastname); ?> - <?php echo e($sluzba->datum); ?> (<?php echo e($sluzba->cas_od); ?> - <?php echo e($sluzba->cas_do); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="start_ulica_id" class="form-label">Počiatočná ulica</label>
                    <select id="start_ulica_id" name="start_ulica_id" class="form-select form-select-lg mb-3" required>
                        <?php if (! ($cesta->exists)): ?>
                            <option selected></option>
                        <?php endif; ?>
                        <?php $__currentLoopData = $ulicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ulica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ulica->id); ?>"<?php echo e($ulica->id === old('ulica_id', $cesta->ulica->id ?? '') ? ' selected' : ''); ?>>
                                <?php echo e($ulica->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="koniec_ulica_id" class="form-label">Konečná ulica</label>
                    <select id="koniec_ulica_id" name="koniec_ulica_id" class="form-select form-select-lg mb-3" required>
                        <?php if (! ($cesta->exists)): ?>
                            <option selected></option>
                        <?php endif; ?>
                        <?php $__currentLoopData = $ulicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ulica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ulica->id); ?>"<?php echo e($ulica->id === old('ulica_id', $cesta->ulica->id ?? '') ? ' selected' : ''); ?>>
                                <?php echo e($ulica->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="cena" class="form-label">Cena</label>
                    <input type="number" step=".01" value="<?php echo e(old('cena', $cesta->cena)); ?>" name="cena" class="form-control" id="cena" required>
                </div>

                <button class="btn btn-warning" type="submit">Uložiť</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/cesta/create_edit.blade.php ENDPATH**/ ?>