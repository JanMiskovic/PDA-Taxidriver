<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-4">
            <form method="post" action="<?php echo e($ulica->exists ? route('ulica.update', $ulica->id) : route('ulica.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php if($ulica->exists): ?>
                    <?php echo method_field('PATCH'); ?>
                <?php endif; ?>
                <div class="mb-3">
                    <label for="name" class="form-label">Nazov</label>
                    <input value="<?php echo e(old('name', $ulica->name)); ?>" type="text" name="name" class="form-control" id="firstname" required>
                </div>

                <div class="mb-3">
                    <label for="mesto_id" class="form-label">Mesto</label>
                    <select id="mesto_id" name="mesto_id" class="form-select form-select-lg mb-3" required>
                        <?php if (! ($ulica->exists)): ?>
                            <option selected></option>
                        <?php endif; ?>
                        <?php $__currentLoopData = $mestos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($mesto->id); ?>"<?php echo e($mesto->id === old('mesto_id', $ulica->mesto->id ?? '') ? ' selected' : ''); ?>>
                                <?php echo e($mesto->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <button class="btn btn-warning" type="submit">Uložiť</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_header.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrazyTaxi\CrazyTaxi\resources\views/ulica/create_edit.blade.php ENDPATH**/ ?>