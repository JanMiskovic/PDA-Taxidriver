<?php

namespace App\Http\Controllers;

use App\Models\taxikar;
use Illuminate\Http\Request;

class TaxikarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $taxikars = taxikar::all();
        return view('taxikar.index', compact('taxikars'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $taxikar = new taxikar();

        return view('taxikar.create_edit', compact('taxikar'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $taxikars = taxikar::create($request->all());
        return redirect()->route('taxikar.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\taxikar  $taxikar
     * @return \Illuminate\Http\Response
     */
    public function show(taxikar $taxikar)
    {
        return view('taxikar.show', compact('taxikar'));
        return redirect()->route('taxikar.index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\taxikar  $taxikar
     * @return \Illuminate\Http\Response
     */
    public function edit(taxikar $taxikar)
    {
        return view('taxikar.create_edit', compact('taxikar'));
        return redirect()->route('taxikar.index');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\taxikar  $taxikar
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, taxikar $taxikar)
    {
        $taxikar->update($request->all());
        return redirect()->route('taxikar.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\taxikar  $taxikar
     * @return \Illuminate\Http\Response
     */
    public function destroy(taxikar $taxikar)
    {
        $taxikar->delete();
        return redirect()->route('taxikar.index');
    }
}
