<?php

namespace App\Http\Controllers;

use App\Models\cesta;
use App\Models\sluzba;
use App\Models\ulica;
use Illuminate\Http\Request;

class CestaController extends Controller
{
    public function index()
    {
        $cestas = cesta::all();
        return view('cesta.index', compact('cestas') );
    }

    public function create()
    {
        $cesta = new cesta();
        $sluzbas = sluzba::all();
        $ulicas = ulica::all();

        return view('cesta.create_edit', compact('ulicas', 'sluzbas', 'cesta'));
    }

    public function store(Request $request)
    {
        $cestas = cesta::create($request->all());
        return redirect()->route('cesta.index');
    }

    public function show(cesta $cesta)
    {
        return view('cesta.show', compact('cesta'));
        return redirect()->route('cesta.index');
    }

    public function edit(cesta $cesta)
    {
        $sluzbas = sluzba::all();
        $ulicas = ulica::all();

        return view('cesta.create_edit', compact('ulicas', 'sluzbas', 'cesta'));
        return redirect()->route('cesta.index');
    }

    public function update(Request $request, cesta $cesta)
    {
        $cesta->update($request->all());
        return redirect()->route('cesta.index');
    }

    public function destroy(cesta $cesta)
    {
        $cesta->delete();
        return redirect()->route('cesta.index');
    }
}
