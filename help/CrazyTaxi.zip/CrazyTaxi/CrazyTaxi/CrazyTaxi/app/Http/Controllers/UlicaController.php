<?php

namespace App\Http\Controllers;

use App\Models\ulica;
use App\Models\mesto;
use Illuminate\Http\Request;

class UlicaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $ulicas = ulica::all();
        return view('ulica.index', compact('ulicas') );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $ulica = new ulica();
        $mestos = mesto::all();

        return view('ulica.create_edit', compact('mestos', 'ulica',));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $ulicas = ulica::create($request->all());
        return redirect()->route('ulica.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ulica  $ulica
     * @return \Illuminate\Http\Response
     */
    public function show(ulica $ulica)
    {
        return view('ulica.show', compact('ulica'));
        return redirect()->route('ulica.index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ulica  $ulica
     * @return \Illuminate\Http\Response
     */
    public function edit(ulica $ulica)
    {
        $mestos = mesto::all();

        return view('ulica.create_edit', compact('mestos', 'ulica'));
        return redirect()->route('ulica.index');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ulica  $ulica
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ulica $ulica)
    {
        $ulica->update($request->all());
        return redirect()->route('ulica.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ulica  $ulica
     * @return \Illuminate\Http\Response
     */
    public function destroy(ulica $ulica)
    {
        $ulica->delete();
        return redirect()->route('ulica.index');
    }
}
