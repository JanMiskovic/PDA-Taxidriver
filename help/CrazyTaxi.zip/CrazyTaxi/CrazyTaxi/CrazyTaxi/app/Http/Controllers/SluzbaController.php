<?php

namespace App\Http\Controllers;

use App\Models\sluzba;
use App\Models\auto;
use App\Models\taxikar;
use Illuminate\Http\Request;

class SluzbaController extends Controller
{
    public function index()
    {
        $sluzbas = sluzba::all();
        return view('sluzba.index', compact('sluzbas') );
    }

    public function create()
    {
        $sluzba = new sluzba();
        $autos = auto::all();
        $taxikars = taxikar::all();

        return view('sluzba.create_edit', compact('taxikars', 'autos', 'sluzba'));
    }

    public function store(Request $request)
    {
        $sluzbas = sluzba::create($request->all());
        return redirect()->route('sluzba.index');
    }

    public function show(sluzba $sluzba)
    {
        return view('sluzba.show', compact('sluzba'));
        return redirect()->route('sluzba.index');
    }

    public function edit(sluzba $sluzba)
    {
        $autos = auto::all();
        $taxikars = taxikar::all();

        return view('sluzba.create_edit', compact('taxikars', 'autos', 'sluzba'));
        return redirect()->route('sluzba.index');
    }

    public function update(Request $request, sluzba $sluzba)
    {
        $sluzba->update($request->all());
        return redirect()->route('sluzba.index');
    }

    public function destroy(sluzba $sluzba)
    {
        $sluzba->delete();
        return redirect()->route('sluzba.index');
    }
}
