<?php

namespace App\Http\Controllers;

use App\Models\auto;
use Illuminate\Http\Request;

class AutoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $autos = auto::all();
        return view('auto.index', compact('autos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $auto = new auto();

        return view('auto.create_edit', compact('auto'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $autos = auto::create($request->all());
        return redirect()->route('auto.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\auto  $auto
     * @return \Illuminate\Http\Response
     */
    public function show(auto $auto)
    {
        return view('auto.show', compact('auto'));
        return redirect()->route('auto.index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\auto  $auto
     * @return \Illuminate\Http\Response
     */
    public function edit(auto $auto)
    {
        return view('auto.create_edit', compact('auto'));
        return redirect()->route('auto.index');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\auto  $auto
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, auto $auto)
    {
        $auto->update($request->all());
        return redirect()->route('auto.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\auto  $auto
     * @return \Illuminate\Http\Response
     */
    public function destroy(auto $auto)
    {
        $auto->delete();
        return redirect()->route('auto.index');
    }
}
