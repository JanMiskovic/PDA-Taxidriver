<?php

namespace App\Http\Controllers;

use App\Models\mesto;
use Illuminate\Http\Request;

class MestoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $mestos = mesto::all();
        return view('mesto.index', compact('mestos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $mesto = new mesto();

        return view('mesto.create_edit', compact('mesto'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $mestos = mesto::create($request->all());
        return redirect()->route('mesto.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\mesto  $mesto
     * @return \Illuminate\Http\Response
     */
    public function show(mesto $mesto)
    {
        return view('mesto.show', compact('mesto'));
        return redirect()->route('mesto.index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\mesto  $mesto
     * @return \Illuminate\Http\Response
     */
    public function edit(mesto $mesto)
    {
        return view('mesto.create_edit', compact('mesto'));
        return redirect()->route('mesto.index');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\mesto  $mesto
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, mesto $mesto)
    {
        $mesto->update($request->all());
        return redirect()->route('mesto.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\mesto  $mesto
     * @return \Illuminate\Http\Response
     */
    public function destroy(mesto $mesto)
    {
        $mesto->delete();
        return redirect()->route('mesto.index');
    }
}
