<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class sluzba extends Model
{
    use HasFactory;

    protected $fillable = [
        'taxikar_id',
        'auto_id',
        'cas_od',
        'cas_do',
        'datum',
    ];

    public function cesta(): hasMany
    {
        return $this->hasMany(cesta::class);
    }

    public function taxikar(): BelongsTo
    {
        return $this->belongsTo(taxikar::class);
    }

    public function auto(): BelongsTo
    {
        return $this->belongsTo(auto::class);
    }
}
