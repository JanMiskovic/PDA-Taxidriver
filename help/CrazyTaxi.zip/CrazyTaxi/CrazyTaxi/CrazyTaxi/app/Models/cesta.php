<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class cesta extends Model
{
    use HasFactory;

    protected $fillable = [
        'sluzba_id',
        'start_ulica_id',
        'koniec_ulica_id',
        'cena',
    ];

    public function sluzba(): BelongsTo
    {
        return $this->BelongsTo(sluzba::class);
    }

    public function ulica(): BelongsTo
    {
        return $this->belongsTo(ulica::class);
    }

    public function start_ulica(): BelongsTo
    {
        return $this->belongsTo(ulica::class);
    }

    public function koniec_ulica(): BelongsTo
    {
        return $this->belongsTo(ulica::class);
    }
}
