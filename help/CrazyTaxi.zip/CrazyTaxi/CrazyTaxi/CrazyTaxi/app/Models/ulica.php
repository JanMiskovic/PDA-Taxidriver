<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ulica extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'mesto_id',
    ];

    public function cesta(): hasMany
    {
        return $this->hasMany(cesta::class);
    }

    public function mesto(): BelongsTo
    {
        return $this->belongsTo(mesto::class);
    }
}
