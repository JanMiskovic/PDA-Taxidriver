názov databázy je "crazytaxi"

naplnenie databázy:
php artisan migrate
php artisan db:seed

spustenie webovej aplikácie:
php artisan serve

adresa: http://127.0.0.1:8000
